import React from 'react';
import './App.css';
import faq from './pages/faq.jsx';


function App() {

  return (
    // <Router>
    //   <Switch>
    //       <Route path="/faq" component={faq} />
    //   </Switch>
    //   </Router>
    <section></section>
  )
}

export default App
