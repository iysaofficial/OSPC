import "../assets/css/styles.css"



const mainhero = () => {
            return (
                // Navbar 
                <section className="main-hero">
                    <div className="container">
                        <div className="hero-wrapper row">
                            <div className="content-text col-lg-6">
                                <div>
                                    <h1>Segera Hadir</h1>
                                    <p>Online Science Project Competition</p>
                                </div>
                                <div>
                                    <a href="" className="btn btn-primary btn-action"> Klik disini untuk Pendaftaran</a>
                                </div>
                            </div>
                            <div className="content-img col-lg-6">
                                <div className="img-logo mx-auto">
                                    <img src="./src/assets/Logo/OSPC-Logo.WebP" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            );
        };
        
        export default mainhero;