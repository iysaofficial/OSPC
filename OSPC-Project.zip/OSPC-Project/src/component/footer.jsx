import "../assets/css/styles.css"

const footer = () => {
    return (
                <section>
                    <footer class="footer-section">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <div class="footer-area-content">
                                            <img
                                                src="./src/assets/Logo/OSPC-Logo.WebP"
                                                alt="logo"
                                                class="main-logo"
                                            />
                                            <p>
                                                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Unde, eveniet explicabo animi corporis minus veritatis iure voluptate deleniti cupiditate sapiente.
                                            </p>
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <div class="single-footer-widget">
                                            <h5>Tautan Informasi</h5>

                                            <ul class="footer-quick-links list-unstyled">
                                                <li><a href="https://iysa.or.id">Support Center</a></li>
                                                <li>
                                                    <a href="htts://wa.me/6281770914129">Call Center</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <div class="single-footer-widget">
                                            <h5>Our Information</h5>

                                            <ul class="footer-quick-links address-link list-unstyled">
                                                <li>
                                                    <a href="https://goo.gl/maps/gEzFyE9gtXEyRfA26"
                                                        ><i class="fa fa-map-marker me-1"></i> Jl. Kemang No.
                                                        63 RT 03 RW 06</a
                                                    >
                                                </li>
                                                <li>
                                                    <a href="mailto:youngscientist.iysa@gmail.com"
                                                        ><i class="fa fa-envelope me-1"></i>
                                                        youngscientist.iysa@gmail.com</a
                                                    >
                                                </li>
                                                <li>
                                                    <a href="tel:+6281770914129"
                                                        ><i class="fa fa-phone me-1"></i> +6281770914129</a
                                                    >
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <div class="single-footer-widget">
                                            <h5>Berlangganan Sosial Kami Untuk Mengikuti</h5>

                                            <ul class="footer-quick-links list-unstyled">
                                                <li>
                                                    <a href=""
                                                        >Team of Expert</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                
                                <hr style={{ border: '3px solid' }} />
                                <div class="copyright-area">
                                    <div class="row align-items-center">
                                            <p className="text-center">
                                                <i class="far fa-copyright me-1"></i>2024 OSPC Official. All
                                                Rights Reserved
                                            </p>

                                        {/* <div class="col-lg-6 col-md-6">
                                            <ul className="list-unstyled">
                                                <li><a routerLink="/">Privacy Policy</a></li>
                                                <li><a routerLink="/">Terms & Conditions</a></li>
                                            </ul>
                                        </div> */}
                                    </div>
                                </div>
                            </div>
                        </footer>
                    </section>
            );
        };
        
        export default footer;