import "../assets/css/styles.css"
import CompFaq from "../component/CompFaq";
import Navigation from "../component/navigation";
import Footer from "../component/footer";

const faq = () => {
            return (
                <>
                <Navigation />
                <CompFaq />
                <Footer />
                </>
            );
        };
        
        export default faq;